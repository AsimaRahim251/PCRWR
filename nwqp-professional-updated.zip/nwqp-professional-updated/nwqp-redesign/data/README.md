# PCRWR Dummy Dataset

Complete dummy dataset based on all screenshots of the National Water Quality Portal.

## Files

| File | Description |
|------|-------------|
| `dataset.json` | Full master dataset (all data in one JSON) |
| `sources.csv` | Detail Report sources list |
| `summarize_report.csv` | City-wise Safe/Unsafe summary |
| `parameterized_report.csv` | Indicator-wise Min/Max & Safe/Unsafe |
| `city_ranking.csv` | City ranking for charts |

## Coverage

- Source Groups: All, Surface Water, Ground Water, Waste Water
- Regions: Punjab, Sindh, KP, Balochistan, AJ&K, GB, ICT
- All cities from filters screenshots
- All 36 water quality parameters
- Detail / Summarize / Parameterized reports
- Yearly safety stats (2003–2025)
- Province-wise & city ranking
- Sample source detail with parameter values

## How to use

Load `dataset.json` in frontend:

```js
fetch('data/dataset.json')
  .then(r => r.json())
  .then(data => {
    // data.detailSources
    // data.summarizeReport
    // data.parameterizedReport
    // data.parameters
    // ...
  });
```
