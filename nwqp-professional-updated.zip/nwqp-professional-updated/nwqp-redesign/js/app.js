/* PCRWR NWQP - Professional Frontend */
let map, charts = {}, currentTileLayer = null, markerLayer = null, heatLayer = null;
let heatmapOn = false;

const citiesByRegion = {
  All: ["All"],
  Punjab: ["All","Bahawalpur","Faisalabad","Gujranwala","Gujrat","Kasur","Lahore","Multan","Rawalpindi","Sargodha","Sheikhupura","Sialkot","Attock","Chakwal","Dera Ghazi Khan","Jhang","Jhelum","Joharabad","Khushab","Lodhran","Mandi Bahauddin","Mianwali","Muzaffar Garh","Rahim Yar Khan","Rajanpur","Sahiwal","Vehari","Lalamusa"],
  Sindh: ["All","Badin","Hyderabad","Karachi","Mirpur Khas","Shaheed Benazir","Sukkur","Tando Allah Yaar","Dadu","Jamshoro","Kashmore","Larkana","Malir","Mithi","Nawabshah","Shikarpur","Sanghar","Tandojam","Thatta"],
  KP: ["All","Abbottabad","Mardan","Mangora","Peshawar","Chitral","Dera Ismail Khan","Kohat","Mansehra","Nowshehra","Swat"],
  Balochistan: ["All","Khuzdar","Loralai","Quetta","Ziarat","Dera Allah Yar","Dera Murad Jamali","Killa Saifullah","Sibi"],
  "AJ&K": ["All","Muzaffarabad","Bagh","Mirpur","Neelam"],
  GB: ["All","Gilgit","Astore","Hunza","Nagar","Skardu"],
  ICT: ["All","Islamabad"]
};

const detailSources = [
  {code:"SB-01-GW",location:"GBPS Village Azim Shah",type:"Hand Pump",province:"Sindh",city:"Shaheed Benazir",status:"Unsafe",lat:26.25,lng:68.35},
  {code:"SB-02-GW",location:"Jamiya Masjid Village Haji Ghulam Shah",type:"Tap",province:"Sindh",city:"Shaheed Benazir",status:"Unsafe",lat:26.28,lng:68.40},
  {code:"TA-05-GW",location:"Taspur Village Government Dispensary",type:"Well",province:"Sindh",city:"Tando Allah Yaar",status:"Safe",lat:25.46,lng:68.72},
  {code:"TA-08-GW",location:"Civil Hospital Tando Allahyar",type:"Hand Pump",province:"Sindh",city:"Tando Allah Yaar",status:"Safe",lat:25.46,lng:68.72},
  {code:"HYD-5",location:"Tayyab Masjid Unit Latifabad",type:"Tap",province:"Sindh",city:"Hyderabad",status:"Safe",lat:25.37,lng:68.35},
  {code:"HYD-6",location:"New Wahdat Colony Qasimabad",type:"Tap",province:"Sindh",city:"Hyderabad",status:"Safe",lat:25.40,lng:68.33},
  {code:"KAR-01",location:"Darweshabad Hotel Yousaf Goth",type:"Tap",province:"Sindh",city:"Karachi",status:"Safe",lat:24.86,lng:67.01},
  {code:"KAR-02",location:"Mamoor Masjid Gulshan-e-Maymar",type:"Tap",province:"Sindh",city:"Karachi",status:"Unsafe",lat:24.92,lng:67.12},
  {code:"FAI-03",location:"Treatment Plant Millat Town",type:"Tubewell",province:"Punjab",city:"Faisalabad",status:"Safe",lat:31.42,lng:73.08},
  {code:"FAI-02",location:"Kalama Wali Tanki Sheikhupura Road",type:"W.Supply",province:"Punjab",city:"Faisalabad",status:"Unsafe",lat:31.44,lng:73.09},
  {code:"GUJ-01",location:"Sheikhupura Chowk GLT Road",type:"Tubewell",province:"Punjab",city:"Gujranwala",status:"Safe",lat:32.16,lng:74.18},
  {code:"GUJ-02",location:"Super Asia Factory",type:"Tubewell",province:"Punjab",city:"Gujranwala",status:"Unsafe",lat:32.15,lng:74.17},
  {code:"SAR-13",location:"IBEX Mart Khushab Road",type:"Hand Pump",province:"Punjab",city:"Sargodha",status:"Safe",lat:32.08,lng:72.67},
  {code:"SAR-14",location:"Govt Central Model School New S.Town",type:"Bore",province:"Punjab",city:"Sargodha",status:"Unsafe",lat:32.09,lng:72.68},
  {code:"MUL-14",location:"132 KV Grid Station Vehari Road",type:"Tubewell",province:"Punjab",city:"Multan",status:"Safe",lat:30.20,lng:71.45},
  {code:"MUL-01",location:"Chah Keomay Wala Opp Zakaria University",type:"Hand Pump",province:"Punjab",city:"Multan",status:"Unsafe",lat:30.21,lng:71.46},
  {code:"LH-01-GW",location:"Model Town Block A",type:"Tube Well",province:"Punjab",city:"Lahore",status:"Safe",lat:31.47,lng:74.32},
  {code:"LH-03-GW",location:"Johar Town Phase 2",type:"Hand Pump",province:"Punjab",city:"Lahore",status:"Unsafe",lat:31.46,lng:74.27},
  {code:"IS-01-GW",location:"F-10 Markaz",type:"Tube Well",province:"ICT",city:"Islamabad",status:"Safe",lat:33.69,lng:73.01},
  {code:"RW-01-GW",location:"Saddar Area",type:"Tube Well",province:"Punjab",city:"Rawalpindi",status:"Safe",lat:33.59,lng:73.04},
  {code:"RW-02-GW",location:"Satellite Town",type:"Hand Pump",province:"Punjab",city:"Rawalpindi",status:"Unsafe",lat:33.63,lng:73.07},
  {code:"PS-01-GW",location:"University Road",type:"Tube Well",province:"KP",city:"Peshawar",status:"Safe",lat:34.01,lng:71.52},
  {code:"QT-01-GW",location:"Jinnah Town",type:"Hand Pump",province:"Balochistan",city:"Quetta",status:"Unsafe",lat:30.18,lng:66.99},
  {code:"BH-01",location:"Sutile Hotel New Bore",type:"Inj. Pump",province:"Punjab",city:"Bahawalpur",status:"Unsafe",lat:29.39,lng:71.68},
  {code:"SK-01-GW",location:"Cantt Area",type:"Tube Well",province:"Punjab",city:"Sialkot",status:"Safe",lat:32.49,lng:74.53},
  {code:"AB-01-GW",location:"Abbottabad City",type:"Hand Pump",province:"KP",city:"Abbottabad",status:"Safe",lat:34.15,lng:73.21},
  {code:"GJ-01-GW",location:"Model Town",type:"Hand Pump",province:"Punjab",city:"Gujrat",status:"Safe",lat:32.57,lng:74.08},
  {code:"FAI-08",location:"Agriculture University Faisalabad",type:"Inj. Pump",province:"Punjab",city:"Faisalabad",status:"Safe",lat:31.43,lng:73.07},
  {code:"GUJ-05",location:"Saghir Park Badni Chowk",type:"Filter Plant",province:"Punjab",city:"Gujranwala",status:"Safe",lat:32.17,lng:74.19},
  {code:"KAR-06",location:"Hamidia Rizvi Univ Near PCSIR",type:"Tap",province:"Sindh",city:"Karachi",status:"Safe",lat:24.90,lng:67.08}
];

const mapLayers = {
  street: {
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    options: { attribution: '&copy; OSM &copy; CARTO', maxZoom: 19 }
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    options: { attribution: '&copy; Esri', maxZoom: 19 }
  },
  terrain: {
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    options: { attribution: '&copy; OpenTopoMap', maxZoom: 17 }
  },
  dark: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    options: { attribution: '&copy; OSM &copy; CARTO', maxZoom: 19 }
  }
};

const CITY_META = {
  Abbottabad: { total: 2, safe: 0, unsafe: 2, contamination: "Turbidity, Iron, Total Coliforms, Copper" },
  Badin: { total: 11, safe: 5, unsafe: 6, contamination: "Iron" },
  Bahawalpur: { total: 25, safe: 6, unsafe: 19, contamination: "Arsenic, Turbidity, Total Coliforms, TDS, Fluoride, Iron, E-Coli, Hardness" },
  Faisalabad: { total: 23, safe: 9, unsafe: 14, contamination: "pH, Nitrate-N, Hardness, Chloride, TDS, Iron, Coliforms, E-Coli, Fluoride" },
  Gilgit: { total: 10, safe: 0, unsafe: 10, contamination: "Turbidity, Total Coliforms, E-Coli" },
  Gujranwala: { total: 14, safe: 7, unsafe: 7, contamination: "Total Coliforms, E-Coli" },
  Gujrat: { total: 9, safe: 9, unsafe: 0, contamination: "None" },
  Hyderabad: { total: 15, safe: 3, unsafe: 12, contamination: "Turbidity, Coliforms, E-Coli, Hardness, Chloride, TDS" },
  Islamabad: { total: 26, safe: 16, unsafe: 10, contamination: "Iron, Total Coliforms, E-Coli, pH" },
  Karachi: { total: 28, safe: 2, unsafe: 26, contamination: "Chloride, TDS, Coliforms, Turbidity, E-Coli, Hardness, Fluoride" },
  Kasur: { total: 10, safe: 9, unsafe: 1, contamination: "Turbidity, Total Coliforms, E-Coli" },
  Lahore: { total: 16, safe: 11, unsafe: 5, contamination: "TDS, Total Coliforms, E-Coli, Turbidity, Iron, Arsenic" },
  Multan: { total: 16, safe: 1, unsafe: 15, contamination: "Arsenic, Total Coliforms" },
  Peshawar: { total: 13, safe: 6, unsafe: 7, contamination: "Iron, pH" },
  Quetta: { total: 37, safe: 15, unsafe: 22, contamination: "Coliforms, Fluoride, E-Coli, Hardness, Chloride, TDS" },
  Rawalpindi: { total: 13, safe: 8, unsafe: 5, contamination: "Coliforms, E-Coli, Nitrate-N, Iron, Hardness, TDS" },
  Sargodha: { total: 24, safe: 4, unsafe: 20, contamination: "Hardness, Nitrate-N, TDS, Chloride, Coliforms, Iron, Fluoride" },
  Sialkot: { total: 10, safe: 9, unsafe: 1, contamination: "Iron, pH" },
  "Shaheed Benazir": { total: 12, safe: 0, unsafe: 12, contamination: "Chloride, TDS, Coliforms, Iron, Hardness, E-Coli" },
  Sukkur: { total: 9, safe: 3, unsafe: 6, contamination: "Turbidity, Iron, Arsenic, Hardness, Chloride, TDS, Fluoride, Coliforms" },
  "Tando Allah Yaar": { total: 8, safe: 4, unsafe: 4, contamination: "Hardness, TDS" }
};

const chartDefaults = {
  fontFamily: 'Inter',
  toolbar: { show: false },
  animations: { enabled: true, speed: 450 }
};

document.addEventListener('DOMContentLoaded', () => {
  updateCityDropdown();
  fillCompareDropdowns();
  initMap();
  applyFilters();
  setTimeout(initHomeCharts, 150);
});

function showView(view) {
  document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
  const el = document.getElementById('view-' + view);
  if (el) el.classList.remove('hidden');
  document.querySelectorAll('.top-nav').forEach(b => {
    if (b.id && b.id.startsWith('nav-')) b.classList.remove('active');
  });
  const nav = document.getElementById('nav-' + view);
  if (nav) nav.classList.add('active');
  if (view === 'stats') setTimeout(initStatsCharts, 150);
  if (view === 'dashboard' && map) setTimeout(() => map.invalidateSize(), 100);
  if (view === 'report') renderReportTable();
  if (view === 'compare') fillCompareDropdowns();
}

function updateCityDropdown() {
  const region = document.getElementById('f-region')?.value || 'All';
  const citySel = document.getElementById('f-city');
  if (!citySel) return;
  const list = citiesByRegion[region] || citiesByRegion.All;
  citySel.innerHTML = list.map(c => `<option value="${c}">${c}</option>`).join('');
}

function getFilteredSources() {
  const status = document.getElementById('f-status')?.value || 'all';
  const region = document.getElementById('f-region')?.value || 'All';
  const city = document.getElementById('f-city')?.value || 'All';
  return detailSources.filter(s => {
    if (status === 'safe' && s.status !== 'Safe') return false;
    if (status === 'unsafe' && s.status !== 'Unsafe') return false;
    if (region !== 'All' && s.province !== region) return false;
    if (city !== 'All' && s.city !== city) return false;
    return true;
  });
}

function applyFilters() {
  const filtered = getFilteredSources();
  updateKPIs(filtered);
  updateHealthScore(filtered);
  updateMapMarkers(filtered);
  if (heatmapOn) updateHeatmap(filtered);
  updateDonut(filtered);
  updateSourceTypeChart(filtered);
  renderReportTable(filtered);
  const hint = document.getElementById('filter-hint');
  if (hint) {
    const region = document.getElementById('f-region')?.value || 'All';
    const city = document.getElementById('f-city')?.value || 'All';
    const status = document.getElementById('f-status')?.value || 'all';
    hint.innerHTML = `Showing <b>${filtered.length}</b> sources` +
      (region !== 'All' ? ` · Region: <b>${region}</b>` : '') +
      (city !== 'All' ? ` · City: <b>${city}</b>` : '') +
      (status !== 'all' ? ` · Status: <b>${status}</b>` : '') +
      `. Map, KPIs, Health Score & charts updated.`;
  }
}

function resetFilters() {
  const s = document.getElementById('f-source');
  const r = document.getElementById('f-region');
  const p = document.getElementById('f-param');
  const st = document.getElementById('f-status');
  if (s) s.value = 'All';
  if (r) r.value = 'All';
  if (p) p.value = 'All';
  if (st) st.value = 'all';
  updateCityDropdown();
  applyFilters();
}

function updateKPIs(list) {
  const total = list.length;
  const safe = list.filter(s => s.status === 'Safe').length;
  const unsafe = total - safe;
  const safePct = total ? ((safe / total) * 100).toFixed(1) : 0;
  const unsafePct = total ? ((unsafe / total) * 100).toFixed(1) : 0;
  const cities = new Set(list.map(s => s.city)).size;
  const el = (id) => document.getElementById(id);
  if (el('kpi-total')) el('kpi-total').textContent = total;
  if (el('kpi-safe')) el('kpi-safe').textContent = safe;
  if (el('kpi-safe-pct')) el('kpi-safe-pct').textContent = total ? `(${safePct}%)` : '';
  if (el('kpi-unsafe')) el('kpi-unsafe').textContent = unsafe;
  if (el('kpi-unsafe-pct')) el('kpi-unsafe-pct').textContent = total ? `(${unsafePct}%)` : '';
  if (el('kpi-cities')) el('kpi-cities').textContent = cities;
}

/* ===== Water Health Score (0-100) ===== */
function calcScore(list) {
  if (!list.length) return 0;
  const safePct = (list.filter(s => s.status === 'Safe').length / list.length) * 100;
  return Math.round(safePct);
}

function scoreLabel(score) {
  if (score >= 80) return 'Excellent';
  if (score >= 60) return 'Good';
  if (score >= 40) return 'Moderate';
  if (score >= 20) return 'Poor';
  return 'Critical';
}

function updateHealthScore(list) {
  const score = calcScore(list);
  const cap = document.getElementById('score-caption');
  if (cap) cap.textContent = scoreLabel(score) + ' · based on safe %';
  if (!charts.healthScore) return;
  const color = score >= 60 ? '#60a5fa' : score >= 40 ? '#94a3b8' : '#64748b';
  charts.healthScore.updateOptions({
    series: [score],
    colors: [color],
    plotOptions: {
      radialBar: {
        dataLabels: {
          name: { show: false },
          value: {
            fontSize: '22px',
            fontWeight: 700,
            color: '#fff',
            offsetY: 6,
            formatter: v => v
          }
        }
      }
    }
  });
}

function initHealthScore() {
  if (!document.querySelector('#chart-health-score') || charts.healthScore) return;
  charts.healthScore = new ApexCharts(document.querySelector('#chart-health-score'), {
    series: [0],
    chart: { type: 'radialBar', height: 120, sparkline: { enabled: true }, ...chartDefaults },
    colors: ['#60a5fa'],
    plotOptions: {
      radialBar: {
        startAngle: -120,
        endAngle: 120,
        hollow: { size: '55%' },
        track: { background: 'rgba(255,255,255,0.15)', strokeWidth: '100%' },
        dataLabels: {
          name: { show: false },
          value: {
            fontSize: '22px',
            fontWeight: 700,
            color: '#fff',
            offsetY: 6,
            formatter: v => v
          }
        }
      }
    },
    stroke: { lineCap: 'round' }
  });
  charts.healthScore.render();
}

/* ===== Map ===== */
function initMap() {
  const el = document.getElementById('map');
  if (!el || map) return;
  map = L.map('map', { zoomControl: true }).setView([30.3753, 69.3451], 5);
  setMapLayer('street');
  markerLayer = L.layerGroup().addTo(map);
}

function setMapLayer(name) {
  if (!map || !mapLayers[name]) return;
  if (currentTileLayer) map.removeLayer(currentTileLayer);
  const cfg = mapLayers[name];
  currentTileLayer = L.tileLayer(cfg.url, cfg.options).addTo(map);
  document.querySelectorAll('#map-layer-switcher button').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.layer === name);
  });
}

function updateMapMarkers(list) {
  if (!map || !markerLayer) return;
  markerLayer.clearLayers();
  if (heatmapOn) return;
  list.forEach(s => {
    const color = s.status === 'Safe' ? '#2563eb' : '#64748b';
    const icon = L.divIcon({
      className: '',
      html: `<div style="width:14px;height:14px;border-radius:50%;background:${color};border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35)"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7]
    });
    L.marker([s.lat, s.lng], { icon })
      .addTo(markerLayer)
      .bindPopup(`<strong>${s.code}</strong><br>${s.location}<br>${s.city}, ${s.province}<br><span style="color:${color};font-weight:600">${s.status}</span>`);
  });
  if (list.length === 1) map.setView([list[0].lat, list[0].lng], 11);
  else if (list.length > 1) {
    const bounds = L.latLngBounds(list.map(s => [s.lat, s.lng]));
    map.fitBounds(bounds.pad(0.25));
  } else map.setView([30.3753, 69.3451], 5);
}

function updateHeatmap(list) {
  if (!map) return;
  if (heatLayer) {
    map.removeLayer(heatLayer);
    heatLayer = null;
  }
  // Intensity higher for unsafe points
  const points = list.map(s => [s.lat, s.lng, s.status === 'Unsafe' ? 0.9 : 0.25]);
  if (!points.length) return;
  heatLayer = L.heatLayer(points, {
    radius: 28,
    blur: 22,
    maxZoom: 12,
    max: 1.0,
    gradient: { 0.2: '#93c5fd', 0.5: '#3b82f6', 0.8: '#1e40af', 1.0: '#0f172a' }
  }).addTo(map);
}

function toggleHeatmap() {
  heatmapOn = !heatmapOn;
  const btnH = document.getElementById('btn-heatmap');
  const btnM = document.getElementById('btn-markers');
  if (btnH) btnH.classList.toggle('active', heatmapOn);
  if (btnM) btnM.classList.toggle('active', !heatmapOn);
  const filtered = getFilteredSources();
  if (heatmapOn) {
    if (markerLayer) markerLayer.clearLayers();
    updateHeatmap(filtered);
  } else {
    if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
    updateMapMarkers(filtered);
  }
}

function showMarkersMode() {
  if (!heatmapOn) return;
  heatmapOn = false;
  const btnH = document.getElementById('btn-heatmap');
  const btnM = document.getElementById('btn-markers');
  if (btnH) btnH.classList.remove('active');
  if (btnM) btnM.classList.add('active');
  if (heatLayer) { map.removeLayer(heatLayer); heatLayer = null; }
  updateMapMarkers(getFilteredSources());
}

function searchMap() {
  const q = (document.getElementById('map-search')?.value || '').trim().toLowerCase();
  if (!q || !map) return;
  const found = detailSources.find(s =>
    s.city.toLowerCase().includes(q) ||
    s.location.toLowerCase().includes(q) ||
    s.code.toLowerCase().includes(q) ||
    s.province.toLowerCase().includes(q)
  );
  if (found) map.setView([found.lat, found.lng], 12);
}

function updateDonut(list) {
  const safe = list.filter(s => s.status === 'Safe').length;
  const unsafe = list.length - safe;
  if (!charts.homeDonut) return;
  charts.homeDonut.updateOptions({
    series: [safe, unsafe],
    plotOptions: {
      pie: {
        donut: {
          labels: { total: { formatter: () => String(list.length) } }
        }
      }
    }
  });
}

function updateSourceTypeChart(list) {
  const counts = {};
  list.forEach(s => {
    const t = s.type || 'Other';
    counts[t] = (counts[t] || 0) + 1;
  });
  const labels = Object.keys(counts);
  const data = Object.values(counts);
  if (!labels.length) { labels.push('No data'); data.push(0); }
  if (charts.sourceTypes) {
    charts.sourceTypes.updateOptions({ labels, series: data });
  }
}

function initHomeCharts() {
  initHealthScore();

  if (document.querySelector('#chart-home-donut') && !charts.homeDonut) {
    charts.homeDonut = new ApexCharts(document.querySelector('#chart-home-donut'), {
      series: [0, 0],
      chart: { type: 'donut', height: 150, ...chartDefaults },
      labels: ['Safe', 'Unsafe'],
      colors: ['#2563eb', '#64748b'],
      legend: { position: 'bottom', fontSize: '11px' },
      plotOptions: {
        pie: {
          donut: {
            size: '68%',
            labels: {
              show: true,
              total: { show: true, label: 'Total', fontSize: '11px', fontWeight: 600, formatter: () => '0' },
              value: { fontSize: '16px', fontWeight: 700 }
            }
          }
        }
      },
      dataLabels: { enabled: false },
      stroke: { width: 2, colors: ['#fff'] }
    });
    charts.homeDonut.render().then(() => updateDonut(getFilteredSources()));
  }

  if (document.querySelector('#chart-home-province') && !charts.homeProvince) {
    charts.homeProvince = new ApexCharts(document.querySelector('#chart-home-province'), {
      series: [
        { name: 'Safe', data: [180, 45, 55, 40, 25] },
        { name: 'Unsafe', data: [320, 95, 70, 65, 35] }
      ],
      chart: { type: 'bar', height: 210, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '52%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['Punjab', 'Sindh', 'KP', 'Balochistan', 'Others'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '11px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.homeProvince.render();
  }

  if (document.querySelector('#chart-home-trend') && !charts.homeTrend) {
    charts.homeTrend = new ApexCharts(document.querySelector('#chart-home-trend'), {
      series: [
        { name: 'Safe %', data: [5, 18, 32, 48, 55, 42, 36, 40, 45, 43, 41, 39] },
        { name: 'Unsafe %', data: [95, 82, 68, 52, 45, 58, 64, 60, 55, 57, 59, 61] }
      ],
      chart: { type: 'area', height: 230, zoom: { enabled: false }, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.35, opacityTo: 0.05, stops: [0, 90, 100] } },
      stroke: { curve: 'smooth', width: 2.5 },
      markers: { size: 4, strokeWidth: 2, strokeColors: '#fff', hover: { size: 6 } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['2003','2005','2008','2010','2012','2015','2017','2019','2021','2023','2024','2025'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { min: 0, max: 100, labels: { style: { fontSize: '11px', colors: '#64748b' }, formatter: v => v + '%' } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 },
      tooltip: { y: { formatter: v => v + '%' } }
    });
    charts.homeTrend.render();
  }

  if (document.querySelector('#chart-home-ranking') && !charts.homeRanking) {
    charts.homeRanking = new ApexCharts(document.querySelector('#chart-home-ranking'), {
      series: [
        { name: 'Safe', data: [95, 40, 35, 38, 25, 22, 28, 35, 18, 25] },
        { name: 'Unsafe', data: [70, 105, 60, 52, 30, 26, 24, 40, 24, 43] }
      ],
      chart: { type: 'bar', height: 230, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '55%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['Lahore','Rawalpindi','Sialkot','Faisalabad','Kasur','Gujrat','Gujranwala','Bahawalpur','Sheikhupura','Multan'],
        labels: { rotate: -40, style: { fontSize: '10px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.homeRanking.render();
  }

  if (document.querySelector('#chart-contaminants') && !charts.contaminants) {
    charts.contaminants = new ApexCharts(document.querySelector('#chart-contaminants'), {
      series: [{ name: 'Affected sources', data: [118, 95, 88, 76, 65, 52, 48, 41] }],
      chart: { type: 'bar', height: 210, ...chartDefaults },
      colors: ['#3b82f6'],
      plotOptions: { bar: { borderRadius: 4, horizontal: true, barHeight: '65%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: true, style: { fontSize: '11px', fontWeight: 600, colors: ['#1e3a8a'] }, formatter: v => v },
      xaxis: {
        categories: ['Total Coliforms', 'TDS', 'Iron', 'Turbidity', 'E-Coli', 'Hardness', 'Arsenic', 'Fluoride'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#475569' } } },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 },
      tooltip: { y: { formatter: v => v + ' sources' } }
    });
    charts.contaminants.render();
  }

  if (document.querySelector('#chart-source-types') && !charts.sourceTypes) {
    charts.sourceTypes = new ApexCharts(document.querySelector('#chart-source-types'), {
      series: [1],
      chart: { type: 'donut', height: 150, ...chartDefaults },
      labels: ['Loading'],
      colors: ['#1e40af', '#2563eb', '#3b82f6', '#60a5fa', '#94a3b8', '#64748b', '#475569'],
      legend: { position: 'bottom', fontSize: '11px' },
      plotOptions: {
        pie: {
          donut: {
            size: '55%',
            labels: { show: true, total: { show: true, label: 'Types', fontSize: '11px', fontWeight: 600 } }
          }
        }
      },
      dataLabels: { enabled: false },
      stroke: { width: 2, colors: ['#fff'] }
    });
    charts.sourceTypes.render().then(() => updateSourceTypeChart(getFilteredSources()));
  }
}

/* ===== City Compare ===== */
function fillCompareDropdowns() {
  const cities = Object.keys(CITY_META).sort();
  const opts = cities.map(c => `<option value="${c}">${c}</option>`).join('');
  const a = document.getElementById('cmp-city-a');
  const b = document.getElementById('cmp-city-b');
  if (a) {
    a.innerHTML = opts;
    a.value = cities.includes('Lahore') ? 'Lahore' : cities[0];
  }
  if (b) {
    b.innerHTML = opts;
    b.value = cities.includes('Karachi') ? 'Karachi' : cities[1] || cities[0];
  }
}

function runCompare() {
  const cityA = document.getElementById('cmp-city-a')?.value;
  const cityB = document.getElementById('cmp-city-b')?.value;
  if (!cityA || !cityB) return;
  if (cityA === cityB) {
    alert('Please select two different cities.');
    return;
  }
  const da = CITY_META[cityA];
  const db = CITY_META[cityB];
  if (!da || !db) return;

  document.getElementById('compare-results')?.classList.remove('hidden');

  const fill = (side, city, d) => {
    const pct = Math.round((d.safe / d.total) * 100);
    const score = pct;
    document.getElementById('cmp-name-' + side).textContent = city;
    document.getElementById('cmp-total-' + side).textContent = d.total;
    document.getElementById('cmp-safe-' + side).textContent = d.safe;
    document.getElementById('cmp-unsafe-' + side).textContent = d.unsafe;
    document.getElementById('cmp-pct-' + side).textContent = pct + '%';
    document.getElementById('cmp-cont-' + side).textContent = d.contamination;
    const badge = document.getElementById('cmp-badge-' + side);
    badge.textContent = scoreLabel(score);
    badge.className = 'chip ' + (score >= 50 ? 'chip-safe' : 'chip-unsafe');

    const elId = 'cmp-score-' + side;
    if (charts['cmp' + side]) {
      charts['cmp' + side].updateOptions({ series: [score] });
    } else {
      charts['cmp' + side] = new ApexCharts(document.getElementById(elId), {
        series: [score],
        chart: { type: 'radialBar', height: 110, sparkline: { enabled: true }, ...chartDefaults },
        colors: [score >= 50 ? '#2563eb' : '#64748b'],
        plotOptions: {
          radialBar: {
            hollow: { size: '55%' },
            track: { background: '#e2e8f0' },
            dataLabels: {
              name: { show: false },
              value: { fontSize: '18px', fontWeight: 700, offsetY: 5, formatter: v => v }
            }
          }
        },
        stroke: { lineCap: 'round' }
      });
      charts['cmp' + side].render();
    }
  };

  fill('a', cityA, da);
  fill('b', cityB, db);

  const pctA = Math.round((da.safe / da.total) * 100);
  const pctB = Math.round((db.safe / db.total) * 100);

  if (charts.compareBar) {
    charts.compareBar.updateOptions({
      xaxis: { categories: [cityA, cityB] },
      series: [
        { name: 'Safe %', data: [pctA, pctB] },
        { name: 'Unsafe %', data: [100 - pctA, 100 - pctB] }
      ]
    });
  } else {
    charts.compareBar = new ApexCharts(document.querySelector('#chart-compare-bar'), {
      series: [
        { name: 'Safe %', data: [pctA, pctB] },
        { name: 'Unsafe %', data: [100 - pctA, 100 - pctB] }
      ],
      chart: { type: 'bar', height: 210, stacked: true, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '45%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: true, formatter: v => v + '%', style: { fontSize: '11px' } },
      xaxis: {
        categories: [cityA, cityB],
        labels: { style: { fontSize: '13px', fontWeight: 600, colors: '#334155' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { max: 100, labels: { formatter: v => v + '%' } },
      legend: { position: 'top', horizontalAlign: 'right' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 },
      tooltip: { y: { formatter: v => v + '%' } }
    });
    charts.compareBar.render();
  }
}

function initStatsCharts() {
  if (document.querySelector('#chart-yearly') && !charts.yearly) {
    charts.yearly = new ApexCharts(document.querySelector('#chart-yearly'), {
      series: [
        { name: 'Safe %', data: [100, 36, 45, 39] },
        { name: 'Unsafe %', data: [0, 64, 55, 61] }
      ],
      chart: { type: 'bar', height: 240, stacked: true, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '48%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['2003', '2015', '2021', '2025'],
        labels: { style: { fontSize: '12px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { max: 100, labels: { style: { fontSize: '11px', colors: '#64748b' }, formatter: v => v + '%' } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 },
      tooltip: { y: { formatter: v => v + '%' } }
    });
    charts.yearly.render();
  }

  if (document.querySelector('#chart-trend-full') && !charts.trendFull) {
    charts.trendFull = new ApexCharts(document.querySelector('#chart-trend-full'), {
      series: [
        { name: 'Safe %', data: [5, 18, 32, 48, 55, 42, 36, 40, 45, 43, 41, 39] },
        { name: 'Unsafe %', data: [95, 82, 68, 52, 45, 58, 64, 60, 55, 57, 59, 61] }
      ],
      chart: { type: 'area', height: 240, zoom: { enabled: false }, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.4, opacityTo: 0.05, stops: [0, 90, 100] } },
      stroke: { curve: 'smooth', width: 2.5 },
      markers: { size: 4, strokeWidth: 2, strokeColors: '#fff', hover: { size: 6 } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['2003','2005','2008','2010','2012','2015','2017','2019','2021','2023','2024','2025'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { min: 0, max: 100, labels: { style: { fontSize: '11px', colors: '#64748b' }, formatter: v => v + '%' } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 },
      tooltip: { y: { formatter: v => v + '%' } }
    });
    charts.trendFull.render();
  }

  if (document.querySelector('#chart-ranking-full') && !charts.rankingFull) {
    charts.rankingFull = new ApexCharts(document.querySelector('#chart-ranking-full'), {
      series: [
        { name: 'Total', data: [165, 145, 95, 90, 55, 48, 52, 75, 42, 68] },
        { name: 'Safe', data: [95, 40, 35, 38, 25, 22, 28, 35, 18, 25] },
        { name: 'Unsafe', data: [70, 105, 60, 52, 30, 26, 24, 40, 24, 43] }
      ],
      chart: { type: 'bar', height: 270, ...chartDefaults },
      colors: ['#cbd5e1', '#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 3, columnWidth: '62%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['Lahore','Rawalpindi','Sialkot','Faisalabad','Kasur','Gujrat','Gujranwala','Bahawalpur','Sheikhupura','Multan'],
        labels: { rotate: -35, style: { fontSize: '10px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.rankingFull.render();
  }

  if (document.querySelector('#chart-province-full') && !charts.provinceFull) {
    charts.provinceFull = new ApexCharts(document.querySelector('#chart-province-full'), {
      series: [
        { name: 'Safe', data: [180, 45, 55, 40, 25] },
        { name: 'Unsafe', data: [320, 95, 70, 65, 35] }
      ],
      chart: { type: 'bar', height: 270, ...chartDefaults },
      colors: ['#2563eb', '#64748b'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '48%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['Punjab', 'Sindh', 'KP', 'Balochistan', 'Others'],
        labels: { style: { fontSize: '12px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      legend: { position: 'top', horizontalAlign: 'right', fontSize: '12px' },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.provinceFull.render();
  }

  if (document.querySelector('#chart-cumulative') && !charts.cumulative) {
    charts.cumulative = new ApexCharts(document.querySelector('#chart-cumulative'), {
      series: [{ name: 'Sources', data: [50, 205, 320, 450, 680, 890, 1050, 1193] }],
      chart: { type: 'area', height: 200, zoom: { enabled: false }, ...chartDefaults },
      colors: ['#2563eb'],
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.4, opacityTo: 0.05, stops: [0, 95, 100] } },
      stroke: { curve: 'smooth', width: 2.5 },
      markers: { size: 4, strokeWidth: 2, strokeColors: '#fff', hover: { size: 6 } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['2003','2008','2012','2015','2018','2021','2023','2025'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.cumulative.render();
  }

  if (document.querySelector('#chart-params') && !charts.paramsChart) {
    charts.paramsChart = new ApexCharts(document.querySelector('#chart-params'), {
      series: [{ name: 'Safe count', data: [78, 65, 68, 72, 80, 55, 58, 42, 48, 30] }],
      chart: { type: 'bar', height: 200, ...chartDefaults },
      colors: ['#2563eb'],
      plotOptions: { bar: { borderRadius: 4, columnWidth: '55%', borderRadiusApplication: 'end' } },
      dataLabels: { enabled: false },
      xaxis: {
        categories: ['EC','Turb','Ca','Mg','Hard','SO4','NO3','TDS','Fe','As'],
        labels: { style: { fontSize: '11px', colors: '#64748b' } },
        axisBorder: { show: false }, axisTicks: { show: false }
      },
      yaxis: { labels: { style: { fontSize: '11px', colors: '#64748b' } } },
      grid: { borderColor: '#e2e8f0', strokeDashArray: 4 }
    });
    charts.paramsChart.render();
  }
}

function renderReportTable(list) {
  const body = document.getElementById('report-body');
  if (!body) return;
  const rows = list || getFilteredSources();
  body.innerHTML = rows.map(s => `
    <tr class="hover:bg-slate-50 transition">
      <td class="px-4 py-2.5 font-mono text-xs font-semibold text-slate-700">${s.code}</td>
      <td class="px-4 py-2.5 text-slate-600">${s.location}</td>
      <td class="px-4 py-2.5 text-slate-500">${s.type}</td>
      <td class="px-4 py-2.5 text-slate-500">${s.province}</td>
      <td class="px-4 py-2.5 text-slate-600 font-medium">${s.city}</td>
      <td class="px-4 py-2.5"><span class="chip ${s.status === 'Safe' ? 'chip-safe' : 'chip-unsafe'}">${s.status}</span></td>
    </tr>`).join('') || `<tr><td colspan="6" class="px-4 py-8 text-center text-slate-400 text-sm">No sources match the current filters.</td></tr>`;
}

function filterReportTable() {
  const q = (document.getElementById('report-search')?.value || '').toLowerCase();
  const base = getFilteredSources();
  const rows = base.filter(s =>
    !q ||
    s.code.toLowerCase().includes(q) ||
    s.location.toLowerCase().includes(q) ||
    s.city.toLowerCase().includes(q) ||
    s.province.toLowerCase().includes(q) ||
    s.status.toLowerCase().includes(q)
  );
  renderReportTable(rows);
}

function submitFeedback() {
  const ok = document.getElementById('fb-ok');
  if (ok) {
    ok.classList.remove('hidden');
    setTimeout(() => ok.classList.add('hidden'), 4000);
  }
}

/* AI */
const AI_DATA = {
  meta: { total: 442, safe: 160, unsafe: 282, safePct: 36.2, unsafePct: 63.8, cities: 48 },
  provinces: {
    Punjab: { safe: 180, unsafe: 320 },
    Sindh: { safe: 45, unsafe: 95 },
    KP: { safe: 55, unsafe: 70 },
    Balochistan: { safe: 40, unsafe: 65 },
    Others: { safe: 25, unsafe: 35 }
  },
  summarize: CITY_META,
  params: {
    "Electrical Conductivity": { min: 0, max: 33500, unit: "µS/cm" },
    "pH": { min: 0, max: 9, unit: "" },
    "Turbidity": { min: 0, max: 960, unit: "NTU" },
    "Chloride": { min: 0, max: 10105, unit: "mg/L" },
    "Total Dissolved Solids": { min: 0, max: 21400, unit: "mg/L" },
    "Iron": { min: 0, max: 13, unit: "mg/L" },
    "Fluoride": { min: 0, max: 6, unit: "mg/L" },
    "Arsenic": { min: 0, max: 104, unit: "µg/L" },
    "Total Coliforms": { min: 0, max: 118, unit: "MPN/100mL" },
    "E-Coli": { min: 0, max: 50, unit: "MPN/100mL" },
    "Total Hardness as CaCO3": { min: 0, max: 7000, unit: "mg/L" },
    "Nitrate-N": { min: 0, max: 29, unit: "mg/L" }
  },
  yearly: {
    "2003": { safe: 100, unsafe: 0 },
    "2015": { safe: 36, unsafe: 64 },
    "2021": { safe: 45, unsafe: 55 },
    "2025": { safe: 39, unsafe: 61 }
  }
};

function toggleAI() {
  const panel = document.getElementById('ai-panel');
  const fab = document.getElementById('ai-fab');
  if (!panel) return;
  panel.classList.toggle('hidden');
  if (fab) fab.style.display = panel.classList.contains('hidden') ? 'flex' : 'none';
  if (!panel.classList.contains('hidden')) document.getElementById('ai-input')?.focus();
}

function appendAIMessage(text, isUser) {
  const box = document.getElementById('ai-messages');
  if (!box) return;
  const div = document.createElement('div');
  if (isUser) {
    div.innerHTML = `<div class="flex justify-end"><div class="ai-user px-3 py-2 text-sm max-w-[90%]">${escapeHtml(text)}</div></div>`;
  } else {
    div.innerHTML = `<div class="text-[10px] font-semibold text-slate-400 mb-1">ASSISTANT</div><div class="ai-bot px-3 py-2 text-sm text-slate-700">${text}</div>`;
  }
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function findCity(q) {
  const lower = q.toLowerCase();
  for (const city of Object.keys(AI_DATA.summarize)) {
    if (lower.includes(city.toLowerCase())) return city;
  }
  return null;
}

function findParam(q) {
  const lower = q.toLowerCase();
  const map = {
    tds: 'Total Dissolved Solids', ec: 'Electrical Conductivity', conductivity: 'Electrical Conductivity',
    arsenic: 'Arsenic', coliform: 'Total Coliforms', coli: 'Total Coliforms', 'e-coli': 'E-Coli', ecoli: 'E-Coli',
    ph: 'pH', iron: 'Iron', fluoride: 'Fluoride', hardness: 'Total Hardness as CaCO3', nitrate: 'Nitrate-N',
    turbidity: 'Turbidity', chloride: 'Chloride'
  };
  for (const [k, v] of Object.entries(map)) if (lower.includes(k)) return v;
  for (const p of Object.keys(AI_DATA.params)) if (lower.includes(p.toLowerCase())) return p;
  return null;
}

function answerAI(question) {
  const q = question.toLowerCase().trim();
  const m = AI_DATA.meta;
  if (/^(hi|hello|hey|good morning|good afternoon)/.test(q)) {
    return 'Hello. I can help with national water quality statistics, city summaries, parameter ranges, and provincial comparisons. What would you like to know?';
  }
  if ((q.includes('total') && q.includes('source')) || q.includes('how many sources')) {
    return `There are <b>${m.total}</b> monitored sources in total.<br>Safe: <b>${m.safe}</b> (${m.safePct}%)<br>Unsafe: <b>${m.unsafe}</b> (${m.unsafePct}%)<br>Cities covered: <b>${m.cities}</b>`;
  }
  if (q.includes('safe') && (q.includes('how many') || q.includes('percent') || q.includes('%') || q.includes('ratio'))) {
    return `Safe sources: <b>${m.safe}</b> out of ${m.total} (<b>${m.safePct}%</b>). Unsafe sources: <b>${m.unsafe}</b> (${m.unsafePct}%).`;
  }
  if (q.includes('unsafe') && (q.includes('how many') || q.includes('percent') || q.includes('%'))) {
    return `Unsafe sources: <b>${m.unsafe}</b> (${m.unsafePct}%). Safe sources: <b>${m.safe}</b> (${m.safePct}%).`;
  }
  if (q.includes('province') || q.includes('punjab') || q.includes('sindh') || q.includes('baloch') || q.includes('compare')) {
    let html = '<b>Province-wise Safe vs Unsafe:</b><ul class="mt-1 space-y-0.5">';
    for (const [prov, d] of Object.entries(AI_DATA.provinces)) html += `<li><b>${prov}</b>: Safe ${d.safe}, Unsafe ${d.unsafe}</li>`;
    return html + '</ul>';
  }
  const city = findCity(q);
  if (city) {
    const d = AI_DATA.summarize[city];
    const pct = Math.round((d.safe / d.total) * 100);
    return `<b>${city}</b> summary:<br>• Total sources: <b>${d.total}</b><br>• Safe: <b>${d.safe}</b> (${pct}%)<br>• Unsafe: <b>${d.unsafe}</b> (${100 - pct}%)<br>• Contamination: <b>${d.contamination}</b>`;
  }
  const param = findParam(q);
  if (param && AI_DATA.params[param]) {
    const p = AI_DATA.params[param];
    return `<b>${param}</b>${p.unit ? ' (' + p.unit + ')' : ''}:<br>• Minimum: <b>${p.min}</b><br>• Maximum: <b>${p.max}</b> ${p.unit}<br>• National safe rate across sources is approximately 36.2%.`;
  }
  if (q.includes('worst') || q.includes('most unsafe') || q.includes('highest unsafe')) {
    const sorted = Object.entries(AI_DATA.summarize).sort((a, b) => b[1].unsafe - a[1].unsafe).slice(0, 5);
    return '<b>Top 5 cities with most unsafe sources:</b><ol class="mt-1">' + sorted.map(([c, d]) => `<li>${c}: ${d.unsafe} unsafe / ${d.total} total</li>`).join('') + '</ol>';
  }
  if (q.includes('best') || q.includes('most safe') || q.includes('safest')) {
    const sorted = Object.entries(AI_DATA.summarize).filter(([, d]) => d.total >= 5).sort((a, b) => (b[1].safe / b[1].total) - (a[1].safe / a[1].total)).slice(0, 5);
    return '<b>Top 5 safest cities (by safe %):</b><ol class="mt-1">' + sorted.map(([c, d]) => `<li>${c}: ${d.safe}/${d.total} safe (${Math.round(d.safe / d.total * 100)}%)</li>`).join('') + '</ol>';
  }
  if (q.includes('year') || q.includes('trend') || q.includes('2021') || q.includes('2025') || q.includes('history')) {
    let html = '<b>Yearly safe percentage:</b><ul class="mt-1">';
    for (const [y, d] of Object.entries(AI_DATA.yearly)) html += `<li>${y}: Safe ${d.safe}% · Unsafe ${d.unsafe}%</li>`;
    return html + '</ul>';
  }
  if (q.includes('arsenic')) {
    const p = AI_DATA.params.Arsenic;
    const cities = Object.entries(AI_DATA.summarize).filter(([, d]) => d.contamination.toLowerCase().includes('arsenic')).map(([c]) => c);
    return `<b>Arsenic</b> range: ${p.min} – ${p.max} µg/L<br>Cities with noted arsenic contamination: <b>${cities.join(', ')}</b>`;
  }
  if (q.includes('help') || q.includes('what can')) {
    return 'You can ask about:<br>• Total / safe / unsafe source counts<br>• Any city (e.g. "Lahore", "Karachi")<br>• Parameter min/max (e.g. "Arsenic max", "TDS")<br>• Province comparison<br>• Worst or safest cities<br>• Yearly safety trend';
  }
  return 'I could not match that question to the dataset. Try asking about a city name, "how many safe sources", "Arsenic maximum", "worst cities", or "Punjab vs Sindh". Type <b>help</b> for more examples.';
}

function askAI() {
  const input = document.getElementById('ai-input');
  if (!input) return;
  const q = input.value.trim();
  if (!q) return;
  appendAIMessage(q, true);
  input.value = '';
  setTimeout(() => appendAIMessage(answerAI(q), false), 200);
}
