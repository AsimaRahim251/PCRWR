# Part 4 — AI Agent + Feedback

**Git branch:** `feature/part-4-ai-feedback`

```
src/components/ai/AIAgent.jsx
src/components/feedback/Feedback.jsx
src/components/ai/ai-feedback.css
```
