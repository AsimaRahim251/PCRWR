import { useState } from 'react';
import { getStats } from '../shared/waterData';
import './ai-feedback.css';

function reply(q) {
  const { total, safe, unsafe, safePct } = getStats();
  const t = (q || '').toLowerCase();
  if (t.includes('unsafe'))
    return `<strong>${unsafe}</strong> sources unsafe (${100 - Math.round(safePct)}%). Critical tab dekho.`;
  if (t.includes('safe') || t.includes('%'))
    return `Safe rate <strong>${safePct}%</strong> — ${safe} sources guidelines pe.`;
  if (t.includes('critical'))
    return 'Critical zones ranked by unsafe %. Map pe jump ke liye row click karo.';
  return `Summary: <strong>${total}</strong> sources · Safe ${safe} (${safePct}%) · Unsafe ${unsafe}.`;
}

export default function AIAgent() {
  const [messages, setMessages] = useState([
    {
      who: 'bot',
      text: 'Assalam-o-Alaikum. Main PCRWR Agent hoon — counts, critical zones, ya priority poochho.',
    },
  ]);
  const [input, setInput] = useState('');

  const ask = (q) => {
    if (!(q = (q || '').trim())) return;
    setMessages((m) => [...m, { who: 'user', text: q }]);
    setTimeout(() => {
      setMessages((m) => [...m, { who: 'bot', text: reply(q) }]);
    }, 400);
  };

  return (
    <div className="page">
      <div className="ai-layout">
        <div className="ai-hero">
          <h2>🤖 AI Water Quality Agent</h2>
          <p>Ask about safe zones, critical areas, or prioritisation</p>
        </div>
        <div className="ai-chat">
          {messages.map((msg, i) => (
            <div key={i} className={`ai-msg ${msg.who}`}>
              <div className="ai-avatar">{msg.who === 'bot' ? '🤖' : '👤'}</div>
              <div
                className="ai-bubble"
                dangerouslySetInnerHTML={{ __html: msg.text }}
              />
            </div>
          ))}
        </div>
        <div className="ai-chips">
          {['How many sources are unsafe?', 'What is the safe rate?', 'List critical zones'].map(
            (c) => (
              <button key={c} type="button" className="ai-chip" onClick={() => ask(c)}>
                {c}
              </button>
            )
          )}
        </div>
        <form
          className="ai-input-row"
          onSubmit={(e) => {
            e.preventDefault();
            ask(input);
            setInput('');
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about groundwater quality..."
          />
          <button type="submit" className="btn btn-primary">
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
