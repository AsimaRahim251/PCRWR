import { useState } from 'react';
import './ai-feedback.css';

export default function Feedback() {
  const [rating, setRating] = useState(4);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    organization: '',
    feedbackType: '',
    foundLooking: 'Yes',
    easeOfUse: 'Easy',
    message: '',
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.fullName || !form.email || !form.feedbackType || !form.message) {
      alert('Please fill all required fields.');
      return;
    }
    const payload = { ...form, rating, submittedAt: new Date().toISOString() };
    try {
      const prev = JSON.parse(localStorage.getItem('pcrwr_feedback') || '[]');
      prev.unshift(payload);
      localStorage.setItem('pcrwr_feedback', JSON.stringify(prev.slice(0, 50)));
    } catch (_) {}
    setSuccess(true);
    setForm({
      fullName: '',
      email: '',
      organization: '',
      feedbackType: '',
      foundLooking: 'Yes',
      easeOfUse: 'Easy',
      message: '',
    });
    setRating(4);
    setTimeout(() => setSuccess(false), 5000);
  };

  return (
    <div className="page">
      <div className="feedback-wrap">
        <div className="feedback-hero">
          <h2>💬 Feedback</h2>
          <p>Help us improve the National Water Quality Portal.</p>
        </div>
        <form className="feedback-form" onSubmit={submit}>
          <div className="fb-grid">
            <div className="fb-field">
              <label>Full Name *</label>
              <input
                value={form.fullName}
                onChange={(e) => set('fullName', e.target.value)}
                placeholder="Enter your full name"
                required
              />
            </div>
            <div className="fb-field">
              <label>Email *</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => set('email', e.target.value)}
                placeholder="you@example.com"
                required
              />
            </div>
            <div className="fb-field">
              <label>Organization / City</label>
              <input
                value={form.organization}
                onChange={(e) => set('organization', e.target.value)}
                placeholder="Optional"
              />
            </div>
            <div className="fb-field">
              <label>Feedback Type *</label>
              <select
                value={form.feedbackType}
                onChange={(e) => set('feedbackType', e.target.value)}
                required
              >
                <option value="">Select type</option>
                <option value="bug">Bug / Error Report</option>
                <option value="data">Data Issue</option>
                <option value="feature">Feature Request</option>
                <option value="ux">UI / UX Suggestion</option>
                <option value="general">General Feedback</option>
              </select>
            </div>
          </div>

          <div className="fb-field">
            <label>Were you able to find what you were looking for?</label>
            <div className="fb-radios">
              {['Yes', 'No', 'Partially'].map((v) => (
                <label key={v} className="fb-radio">
                  <input
                    type="radio"
                    name="found"
                    checked={form.foundLooking === v}
                    onChange={() => set('foundLooking', v)}
                  />{' '}
                  {v}
                </label>
              ))}
            </div>
          </div>

          <div className="fb-field">
            <label>Overall rating</label>
            <div className="fb-stars">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  className={`star ${n <= rating ? 'active' : ''}`}
                  onClick={() => setRating(n)}
                >
                  ★
                </button>
              ))}
            </div>
          </div>

          <div className="fb-field">
            <label>Your Message *</label>
            <textarea
              rows={5}
              value={form.message}
              onChange={(e) => set('message', e.target.value)}
              placeholder="Describe your feedback..."
              required
            />
          </div>

          <div className="fb-actions">
            <button type="submit" className="btn btn-primary">
              Submit Feedback
            </button>
          </div>

          {success && (
            <div className="fb-success">
              <strong>Thank you!</strong> Your feedback has been recorded.
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
